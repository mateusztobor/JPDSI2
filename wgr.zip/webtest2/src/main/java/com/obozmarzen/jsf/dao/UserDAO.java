package com.obozmarzen.jsf.dao;

import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import com.obozmarzen.jsf.entities.User;

@Named
@RequestScoped
public class UserDAO {
	@PersistenceContext
	protected EntityManager em;
	public User getUserFromDatabase(String name, String password) {
		User u = null;

		Query query = em.createQuery("select u FROM User u where u.name=:name and u.password=:password");
		query.setParameter("name", name);
		query.setParameter("password", password);
		
		try {
			User user = (User) query.getSingleResult();
			u = new User();
			u.setId(user.getId());
			u.setEmail(user.getEmail());
			u.setName(name);
			u.setPassword(password);
			
			u.setRole(user.getRole());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return u;
	}
	
	public List<String> getUserRolesFromDatabase(User user) {
		ArrayList<String> roles = new ArrayList<String>();
		roles.add(user.getRole());
		return roles;
	}
}
